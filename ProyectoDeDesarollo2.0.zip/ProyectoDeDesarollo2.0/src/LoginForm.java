import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;


public class LoginForm extends JFrame {
    private JTextField textF1;
    private JPasswordField passwordF1;
    private JButton okButton;
    private JButton cancelarButton;
    private JPanel LoginPanel;
    private JLabel Us;


    public LoginForm() {
        setTitle("Login");
        setContentPane(LoginPanel);
        setMinimumSize(new Dimension(650, 670));
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);



        okButton.setOpaque(false);
        okButton.setContentAreaFilled(false);
        okButton.setBorderPainted(false);

        cancelarButton.setOpaque(false);
        cancelarButton.setContentAreaFilled(false);
        cancelarButton.setBorderPainted(false);


        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            String user= textF1.getText();
            String password= passwordF1.getText();
            // SELECT name, password, privilegio FROM users WHERE activo = 1 AND name = 'MarcoRios';
                String url="SELECT name, password, privilegio FROM users WHERE activo = 1 AND name ='"+user+"'";
                try {
                    Connection con = Conexion.obtenerConexion();
                    PreparedStatement ps = con.prepareStatement(url);
                    ResultSet rs = ps.executeQuery();

                    if (rs.next()){
                        String u=rs.getString("name");
                        String p=rs.getString("password");
                        String priv=rs.getString("privilegio");

                        if (password.equals(p)){

                            if (priv.equals("maestros")){
                                Maestros maestros = new Maestros(null);
                                maestros.setVisible(true);
                                dispose();
                            } else if (priv.equals("alumnos")) {
                                Alumnos3 alumnos3 = new Alumnos3();
                                alumnos3.setVisible(true);
                                dispose();

                            }
                        }else {
                            JOptionPane.showMessageDialog(null,"La contraseña es incorrecta");
                        }
                    }else {
                        JOptionPane.showMessageDialog(null,"El usuario no existe");
                    }
                }catch (SQLException ex){
                    System.out.println(ex.toString());
                }
            }
        });
        cancelarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }
    public class Conexion{
        public static Connection obtenerConexion(){
            String url="jdbc:mysql://localhost:3306/rios_bd?user=root&password=maxi.com123";
            try {
                Connection con = DriverManager.getConnection(url);
                return con;
            }catch (SQLException ex){
                System.out.println(ex.toString());
                return null;
            }
        }
    }
}