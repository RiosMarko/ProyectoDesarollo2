import java.sql.Connection;
import java.sql.DriverManager;

public class ConexionSQL {
        Connection conectar=null;
        public Connection conexion() {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                conectar = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/rios_bd", "root", "maxi.com123");
                System.out.println("Conexion exitosa");

            } catch (Exception e) {
                System.out.println("No se pudo establecer la conexion con la Base de datos");
            }

            return conectar;
        }
}



