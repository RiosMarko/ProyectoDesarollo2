import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;


public class Alumnos extends JFrame {
    private JPanel AlumnoPanel;
    private JTable TabAlu;
    private JButton actualizarButton;
    private JButton eliminarButton;
    private JButton guardarButton;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JButton regresarButton;

    ConexionSQL cc = new ConexionSQL();
    Connection con = cc.conexion();


    public Alumnos(JFrame parent) {
        setTitle("Alumnos");
        setContentPane(AlumnoPanel);
        setMinimumSize(new Dimension(650, 670));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);
        mostrarDatos();

        regresarButton.setOpaque(false);
        regresarButton.setContentAreaFilled(false);
        regresarButton.setBorderPainted(false);

        actualizarButton.setOpaque(false);
        actualizarButton.setContentAreaFilled(false);
        actualizarButton.setBorderPainted(false);


        guardarButton.setOpaque(false);
        guardarButton.setContentAreaFilled(false);
        guardarButton.setBorderPainted(false);

        eliminarButton.setOpaque(false);
        eliminarButton.setContentAreaFilled(false);
        eliminarButton.setBorderPainted(false);


        TabAlu.setModel(new DefaultTableModel(
                null,
                new String[]{"Expediente", "Nombre", "Calificación"}
        ));
        TabAlu.setVisible(true);
        mostrarDatos();


        guardarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                insertarDatos();
                limpiarCajas();
            }
        });
        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrar();
                limpiarCajas();
                mostrarDatos();
            }
        });
        actualizarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarDatos();
            }
        });
        regresarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Maestros maestros = new Maestros(null);
                dispose();


            }
        });
        TabAlu.addMouseMotionListener(new MouseMotionAdapter() {
        });
        TabAlu.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
            }
        });
    }

    public void mostrarDatos() {
        String[] titulos = {"Expediente", "Nombre", "Calificacion"};
        String[] registros = new String[4];
        DefaultTableModel model = new DefaultTableModel(null, titulos);
        String SQL = "select * from tabalu";

        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(SQL);

            while (rs.next()) {

                registros[2] = rs.getString("Expediente");
                registros[1] = rs.getString("Nombre");
                registros[0] = rs.getString("Calificacion");

                model.addRow(registros);

            }
            TabAlu.setModel(model);
        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, "Error al mostrar datos" + e.getMessage());

        }
    }

    public void limpiarCajas() {
        textField1.setText("");
        textField2.setText("");
        textField3.setText("");
    }

    public void insertarDatos() {

        try {
            String SQL = "insert into TabAlu (Expediente,Nombre,Calificacion) values (?,?,?)";
            PreparedStatement pst = con.prepareStatement(SQL);

            pst.setString(1, textField1.getText());
            pst.setString(2, textField2.getText());
            pst.setString(3, textField3.getText());

            pst.execute();
            JOptionPane.showMessageDialog(null, "Registro Exitoso");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error de Registro" + e.getMessage());
        }
    }

    public void borrar() {
                try {
                    // Get the connection to the database
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/rios_bd", "root", "maxi.com123");


                    // Create a button to delete the selected row
                        eliminarButton.addActionListener(e -> {
                        // Get the selected row
                        int selectedRow = TabAlu.getSelectedRow();
                            if (selectedRow == -1) {
                            }


                        // Create the SQL query to delete the row
                        String sql = "DELETE FROM tabalu WHERE expediente = ?";

                        try {
                            // Create a prepared statement with the SQL query
                            PreparedStatement statement = conn.prepareStatement(sql);

                            // Set the parameter for the prepared statement
                            statement.setInt(1, selectedRow);


                            // Execute the prepared statement
                            statement.executeUpdate();

                            // Remove the row from the table
                            DefaultTableModel model = (DefaultTableModel) TabAlu.getModel();
                            model.removeRow(selectedRow);

                            // Show a message dialog
                            JOptionPane.showMessageDialog(null, "Row deleted successfully");

                        } catch (SQLException ex) {
                            System.out.println("An error occurred: " + ex.getMessage());
                        }
                    });

                   // conn.close();
                } catch (SQLException e) {
                    System.out.println("An error occurred: " + e.getMessage());
                }
            }
        }












