package imagenes;

import javax.swing.*;

public class Dario extends JFrame {
    private JPanel panel1;
}
