import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;


public class Salones extends JFrame {
    private JPanel SalonesPanel;
    private JTable tabmateria;
    private JButton actualizarButton;
    private JButton borrarButton;
    private JButton guardarButton;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JButton regresarButton;

    ConexionSQL cc= new ConexionSQL();
    Connection con= cc.conexion();


    public Salones(JFrame parent) {
        setTitle("Materias");
        setContentPane(SalonesPanel);
        setMinimumSize(new Dimension(650, 670));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);
        mostrarDatos();

        regresarButton.setOpaque(false);
        regresarButton.setContentAreaFilled(false);
        regresarButton.setBorderPainted(false);

        actualizarButton.setOpaque(false);
        actualizarButton.setContentAreaFilled(false);
        actualizarButton.setBorderPainted(false);


        guardarButton.setOpaque(false);
        guardarButton.setContentAreaFilled(false);
        guardarButton.setBorderPainted(false);

        borrarButton.setOpaque(false);
        borrarButton.setContentAreaFilled(false);
        borrarButton.setBorderPainted(false);


        tabmateria.setModel(new DefaultTableModel(
                null,
                new String[]{"Salon","Hora","Materia"}
        ));
        tabmateria.setVisible(true);
        mostrarDatos();


        guardarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                insertarDatos();
                limpiarCajas();
                mostrarDatos();
            }
        });
        borrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrar();
                limpiarCajas();
            }
        });
        actualizarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarDatos();
            }
        });
        regresarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Maestros maestros = new Maestros(null);
                dispose();
            }
        });
        tabmateria.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
            }
        });
    }
    public void mostrarDatos(){
        String[] titulos={"Salon","Hora","Materia"};
        String[] registros= new String[4];
        DefaultTableModel model=new DefaultTableModel(null,titulos);
        String SQL="select * from tabmateria";

        try{
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(SQL);

            while(rs.next()){

                registros[0]=rs.getString("Salon");
                registros[2]=rs.getString("Materia");
                registros[1]=rs.getString("Hora");

                model.addRow(registros);

            }
            tabmateria.setModel(model);
        }catch (Exception e){

            JOptionPane.showMessageDialog(null,"Error al mostrar datos"+e.getMessage());

        }
    }
    public void limpiarCajas(){
        textField1.setText("");
        textField2.setText("");
        textField3.setText("");
    }
    public void insertarDatos(){

        try{
            String SQL="insert into tabmateria (Salon,Hora,Materia) values (?,?,?)";
            PreparedStatement pst = con.prepareStatement(SQL);

            pst.setString(1,textField3.getText());
            pst.setString(2,textField1.getText());
            pst.setString(3,textField2.getText());

            pst.execute();
            JOptionPane.showMessageDialog(null,"Registro Exitoso");

        }catch (Exception e){
            JOptionPane.showMessageDialog(null,"Error de Registro"+e.getMessage());
        }
    }
    public void borrar(){
        try {
            // Get the connection to the database
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/rios_bd", "root", "maxi.com123");


            // Create a button to delete the selected row
            borrarButton.addActionListener(e -> {
                // Get the selected row
                int selectedRow = tabmateria.getSelectedRow();

                // Create the SQL query to delete the row
                String sql = "DELETE FROM tabalu WHERE expediente = ?";

                try {
                    // Create a prepared statement with the SQL query
                    PreparedStatement statement = conn.prepareStatement(sql);

                    // Set the parameter for the prepared statement
                    statement.setInt(1, selectedRow);

                    // Execute the prepared statement
                    statement.executeUpdate();

                    // Remove the row from the table
                    DefaultTableModel model = (DefaultTableModel) tabmateria.getModel();
                    model.removeRow(selectedRow);

                    // Show a message dialog
                    JOptionPane.showMessageDialog(null, "Row deleted successfully");
                } catch (SQLException ex) {
                    System.out.println("An error occurred: " + ex.getMessage());
                }
            });

            // conn.close();
        } catch (SQLException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
}

