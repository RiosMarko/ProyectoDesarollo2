public class User {
    public String name;
    public String email;
    public String password;
    public String privilegio;
}
