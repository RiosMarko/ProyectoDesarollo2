
public class Main {
    public static void main(String[] args) {
        LoginForm loginForm = new LoginForm();
        loginForm.setVisible(true);

    }
}

//Usuarios "MarcoRios" y "DarioAtondo"
//Contraseña "123"



