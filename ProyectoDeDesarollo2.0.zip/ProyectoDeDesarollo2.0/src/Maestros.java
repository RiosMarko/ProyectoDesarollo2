import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Maestros extends JFrame {
    private JPanel panel1;
    private JButton salonesButton;
    private JButton A1Button;
    private JButton regresarButton;

    public Maestros(JFrame parent) {
        setTitle("Inicio");
        setContentPane(panel1);
        setMinimumSize(new Dimension(650, 670));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);

        regresarButton.setOpaque(false);
        regresarButton.setContentAreaFilled(false);
        regresarButton.setBorderPainted(false);

        salonesButton.setOpaque(false);
        salonesButton.setContentAreaFilled(false);
        salonesButton.setBorderPainted(false);

        A1Button.setOpaque(false);
        A1Button.setContentAreaFilled(false);
        A1Button.setBorderPainted(false);

        setVisible(true);

        A1Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Alumnos alumno = new Alumnos(null);
                alumno.setVisible(true);
                dispose();
            }
        });
        salonesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Salones salones = new Salones(null);
                salones.setVisible(true);
                dispose();
            }
        });
        regresarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                LoginForm loginForm = new LoginForm();
                loginForm.setVisible(true);
                dispose();
            }

        });


    }

}