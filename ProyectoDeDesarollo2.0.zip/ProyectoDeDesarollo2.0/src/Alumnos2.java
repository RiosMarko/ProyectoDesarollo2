import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class Alumnos2 extends JFrame{
    private JPanel AlumnoPanel;
    private JTable TabAlu;
    private JButton regresarButton;


    ConexionSQL cc= new ConexionSQL();
    Connection con= cc.conexion();


    public Alumnos2(JFrame parent) {
        setTitle("Alumnos");
        setContentPane(AlumnoPanel);
        setMinimumSize(new Dimension(650, 670));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);
        mostrarDatos();

        regresarButton.setOpaque(false);
        regresarButton.setContentAreaFilled(false);
        regresarButton.setBorderPainted(false);




        TabAlu.setModel(new DefaultTableModel(
                null,
                new String[]{"Expediente", "Nombre", "Calificación"}
        ));
        TabAlu.setVisible(true);
        mostrarDatos();

        regresarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               Alumnos3 alumnos3 = new Alumnos3();
               alumnos3.setVisible(true);
                dispose();


            }
        });
    }

    public void mostrarDatos(){
        String[] titulos={"Expediente","Nombre","Calificacion"};
        String[] registros= new String[4];
        DefaultTableModel model=new DefaultTableModel(null,titulos);
        String SQL="select * from tabalu";

        try{
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(SQL);

            while(rs.next()){

                registros[2]=rs.getString("Expediente");
                registros[1]=rs.getString("Nombre");
                registros[0]=rs.getString("Calificacion");

                model.addRow(registros);

            }
            TabAlu.setModel(model);
        }catch (Exception e){

            JOptionPane.showMessageDialog(null,"Error al mostrar datos"+e.getMessage());

        }
    }
}


